let currentIndex = 0;

const images = [
  { src: "Images/images1.jpg", description: "Beautiful red cardinal" },
  { src: "Images/images10.jpg", description: "Elegant blue jay" },
  { src: "Images/images12.jpg", description: "Chirping sparrow" },
  { src: "Images/images13.jpg", description: "Graceful white dove" },
  { src: "Images/images14.jpg", description: "Golden canary in the wild" },
  { src: "Images/images15.jpg", description: "Majestic bald eagle" },
  { src: "Images/images16.jpg", description: "Colorful hummingbird" },
  { src: "Images/images17.jpg", description: "Tropical parrot" },
  { src: "Images/images18.jpg", description: "Soaring hawk" },
  { src: "Images/images19.jpg", description: "Eurasian Magpie" },
  { src: "Images/images20.jpg", description: "Peacock" },
  { src: "Images/images21.jpg", description: "Flamingo" },
  { src: "Images/images22.jpg", description: "Goldfinch" },
  { src: "Images/images23.jpg", description: "Sandpiper" },
  { src: "Images/images24.jpg", description: "Google Pheasan" },
  { src: "Images/images26.jpg", description: "Roadrunner" },
  { src: "Images/images27.jpg", description: "Falcon" },
  { src: "Images/images28.jpg", description: "Heron" },
  { src: "Images/images29.jpg", description: "Oriole" },
  { src: "Images/images3.jpg", description: "Lapwing" },
  { src: "Images/images30.jpg", description: "Warbler" },
  { src: "Images/images31.jpg", description: "Sparrowhawk" },
  { src: "Images/images32.jpg", description: "Eurasian Magpie" },
  { src: "Images/images33.jpg", description: "Harrier" },
  { src: "Images/images34.jpg", description: "Kingfisher" },
  { src: "Images/images35.jpg", description: "Pelican" },
  { src: "Images/images36.jpg", description: "Canary" },
  { src: "Images/images37.jpg", description: "Swallow" },
  { src: "Images/images38.jpg", description: "Swan" },
  { src: "Images/images5.jpg", description: "Cardinal" },
  { src: "Images/images6.jpg", description: "Kookaburra" },
  { src: "Images/images8.jpg", description: "Blue Jay" },
  { src: "Images/images9.jpg", description: "Dove" },
];

const mainImage = document.querySelector(".main-image");
const imageGrid = document.querySelector(".image-grid");

// Dynamically add images to the grid
images.forEach((image, index) => {
  const imgElement = document.createElement("img");
  imgElement.src = image.src;
  imgElement.alt = image.description;
  imgElement.classList.add("grid-image");
  imgElement.dataset.index = index;

  // Create description tooltip
  const tooltip = document.createElement("div");
  tooltip.classList.add("tooltip");
  tooltip.textContent = image.description;

  const wrapper = document.createElement("div");
  wrapper.classList.add("image-wrapper");
  wrapper.appendChild(imgElement);
  wrapper.appendChild(tooltip);

  imageGrid.appendChild(wrapper);

  imgElement.addEventListener("click", () => {
    currentIndex = index;
    updateMainImage();
  });
});

function navigate(isNext) {
  currentIndex =
    (currentIndex + (isNext ? 1 : -1) + images.length) % images.length;
  updateMainImage();
}

const descriptionElement = document.querySelector('.image-description');

function updateMainImage() {
    mainImage.src = images[currentIndex].src;
    mainImage.alt = images[currentIndex].description;
    descriptionElement.textContent = images[currentIndex].description;
   
}

// Theme Toggle Functionality
function toggleTheme() {
  const html = document.documentElement;
  const currentTheme = html.getAttribute('data-theme');
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  
  html.setAttribute('data-theme', newTheme);
  localStorage.setItem('theme', newTheme);
  
  // Update button text
  const themeButton = document.querySelector('.theme-toggle');
  themeButton.textContent = newTheme === 'dark' ? '🌞 Light Mode' : '🌙 Dark Mode';
}

// Initialize theme from localStorage or system preference
function initializeTheme() {
  const savedTheme = localStorage.getItem('theme');
  const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  
  if (savedTheme) {
    document.documentElement.setAttribute('data-theme', savedTheme);
  } else if (systemDark) {
    document.documentElement.setAttribute('data-theme', 'dark');
  }
  
  // Set initial button text
  const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
  const themeButton = document.querySelector('.theme-toggle');
  themeButton.textContent = currentTheme === 'dark' ? '🌞 Light Mode' : '🌙 Dark Mode';
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', initializeTheme);

// Optional: Watch for system theme changes
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
  if (!localStorage.getItem('theme')) {
    document.documentElement.setAttribute('data-theme', e.matches ? 'dark' : 'light');
  }
});

// Initialize first image
updateMainImage();
