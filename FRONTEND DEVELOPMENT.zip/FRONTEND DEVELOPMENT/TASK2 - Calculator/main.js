let displayValue = '0';
let isPoweredOn = false;
const display = document.getElementById('display');
const powerButton = document.getElementById('powerButton');
const powerIndicator = document.getElementById('powerIndicator');
const allButtons = document.querySelectorAll('.buttons button');

function updateDisplay() {
    display.textContent = displayValue;
}

function togglePower() {
    isPoweredOn = !isPoweredOn;
    powerButton.textContent = isPoweredOn ? 'ON' : 'OFF';
    powerButton.classList.toggle('on');
    powerIndicator.classList.toggle('on');
    display.classList.toggle('off');
    
    // Enable/disable all buttons except power
    allButtons.forEach(button => {
        button.disabled = !isPoweredOn;
    });

    if (!isPoweredOn) {
        displayValue = '0';
        updateDisplay();
    }
}

function appendNumber(num) {
    if (!isPoweredOn) return;
    if (displayValue === '0' && num !== '.') {
        displayValue = num;
    } else {
        displayValue += num;
    }
    updateDisplay();
}

function appendOperator(operator) {
    if (!isPoweredOn) return;
    displayValue += operator;
    updateDisplay();
}

function clearDisplay() {
    if (!isPoweredOn) return;
    displayValue = '0';
    updateDisplay();
}

function backspace() {
    if (!isPoweredOn) return;
    if (displayValue.length === 1) {
        displayValue = '0';
    } else {
        displayValue = displayValue.slice(0, -1);
    }
    updateDisplay();
}

function calculate() {
    if (!isPoweredOn) return;
    try {
        // Using Function instead of eval for better security
        displayValue = Function('"use strict";return (' + displayValue + ')')().toString();
        updateDisplay();
    } catch (error) {
        displayValue = 'Error';
        updateDisplay();
        setTimeout(clearDisplay, 1000);
    }
}

// Initialize calculator in powered off state
togglePower();